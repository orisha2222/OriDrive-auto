# OriDrive Auto storefront

A mobile-first, vanilla HTML/CSS/JavaScript e-commerce frontend for OriDrive Auto.

## Run it

Open `index.html` in a browser, or serve this folder with any static server:

```bash
python3 -m http.server 8000
```

## Edit business details

All frequently changed business values live in `config.js`:

- WhatsApp number
- phone and email
- delivery fees and estimated times
- Addis Ababa location
- social links

Replace the product photos and product data in `app.js` when real inventory photography is ready. The current images are professional remote placeholders.

## Included

- Hash-routed Home, Shop, Product, About, Reviews, Delivery, Contact, Cart and Checkout views
- Search, category filters, sorting and stock labels
- Persistent cart with quantity controls via `localStorage`
- Checkout summary and pre-filled WhatsApp order generation
- Responsive layout, semantic controls, accessible labels and SEO metadata
- No invented customer claims or reviews

The checkout is intentionally prepared for a future Ethiopian payment gateway integration. The current payment methods collect the customer's choice and send the order to WhatsApp.