// Edit this file first when replacing the starter business details.
window.ORIDRIVE_CONFIG = {
  brand: "ORIDRIVE AUTO",
  tagline: "Premium accessories for a better drive.",
  currency: "ETB",
  whatsappNumber: "251900000000",
  phone: "+251 900 000 000",
  email: "hello@oridriveauto.et",
  location: "Addis Ababa, Ethiopia",
  delivery: {
    addis: { label: "Addis Ababa", fee: 150, eta: "1–2 business days" },
    nationwide: { label: "Nationwide Ethiopia", fee: 350, eta: "2–5 business days" }
  },
  social: {
    instagram: "#",
    tiktok: "#",
    facebook: "#"
  }
};